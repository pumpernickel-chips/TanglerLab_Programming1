import java.util.InputMismatchException;
import java.util.Scanner;

public class Printer {
    public static void main(String[] args){
        Rectangle creation = new Rectangle(0, 0, "");
        Scanner enter_command = new Scanner(System.in);
        Scanner enter_width = new Scanner(System.in);
        Scanner enter_height = new Scanner(System.in);
        Scanner enter_symbol = new Scanner(System.in);
        Scanner save_prompt = new Scanner(System.in);
        int creation_counter=0;
        String command = "";
        boolean printing = true;
        while(printing){
            while(command.isEmpty()) {
                System.out.print("\nCommands available:\n\t 'create' - replace the stored rectangle\n\t'display' - show information about the stored rectangle\n\t 'render' - render the stored rectangle\n\t   'exit' - leave the program\n\nEnter new command: ");
                command = enter_command.nextLine();
                if(command.equals("create") || command.equals("Create") || command.equals("CREATE") || command.equals("display") || command.equals("Display") || command.equals("DISPLAY") || command.equals("render") || command.equals("Render") || command.equals("RENDER") || command.equals("exit") || command.equals("Exit") || command.equals("EXIT")) {
                    break;
                } else {
                    System.out.print("\nEnter a valid command!");
                    command="";
                }
            }
            while(command.equals("create") || command.equals("Create") || command.equals("CREATE")) {
                if(creation_counter==1){
                    System.out.print("\nWARNING: This will overwrite the previous rectangle!\nType 'y' to overwrite & continue, or 'n' to cancel: ");
                    Scanner overwrite_prompt = new Scanner(System.in);
                    String overwrite= overwrite_prompt.nextLine();
                    if(overwrite.equals("y") || overwrite.equals("Y")){
                        creation_counter=0;
                        continue;
                    } else {
                        command="";
                        break;
                    }
                }
                int width=0;
                int height=0;
                String symbol="";
                boolean not_done_yet = true;
                while(not_done_yet) {
                    try{
                        System.out.print("\nEnter the rectangle's width: ");
                        width = enter_width.nextInt();
                    } catch(InputMismatchException e) {
                        System.out.println("\nNot a valid width! Start over!");
                        break;
                    }
                    try{
                        System.out.print("Enter the rectangle's height: ");
                        height = enter_height.nextInt();
                    } catch(InputMismatchException e) {
                        System.out.println("\nNot a valid height! Start over!");
                        break;
                    }
                    System.out.print("Enter the rectangle's symbol: ");
                    symbol = enter_symbol.nextLine();
                    if(symbol.length()==1){
                        not_done_yet=false;
                    } else {
                        System.out.println("\nOnly one symbol allowed! Start over!");
                        break;
                    }
                }
                if(not_done_yet){
                    command="";
                    break;
                }
                Rectangle temp_creation = new Rectangle(width, height, symbol);
                String temp_details = temp_creation.get_details_text();
                System.out.print("\nSave the rectangle with the following attributes?\n" + temp_details + "Type 'y' to save or 'n' to cancel: ");
                String save = save_prompt.nextLine();
                if(save.equals("Y") || save.equals("y")) {
                    creation = new Rectangle(width, height, symbol);
                    String details = temp_details;
                    System.out.println("\nSaved!");
                    creation_counter=creation_counter+1;
                }
                temp_details="";
                temp_creation = new Rectangle(0, 0, "");
                command="";
            }
            while(command.equals("display") || command.equals("Display") || command.equals("DISPLAY")) {
                String display_details_text = creation.get_details_text();
                if(display_details_text.equals("\t Width: " + 0 + "\n\tHeight: " + 0 + "\n\tSymbol: " + "" +"\n")){
                    System.out.println("\nCreate a rectangle first!");
                } else {
                    System.out.println("Current stored rectangle details:\n" + display_details_text);
                }
                command="";
            }
            while(command.equals("render") || command.equals("Render") || command.equals("RENDER")) {
                String render=creation.toString();
                if(render.isEmpty()){
                    System.out.println("\nBehold! The world's smallest rectangle (it's here somewhere, but it's very small).");
                } else {
                    System.out.println(render);
                    System.out.println("\nRectangle Area: " + creation.calculate_area() + " " + creation.unit_symbol() + "'s squared\n");
                    System.out.println("Rectangle Perimeter: " + creation.calculate_perimeter() + " " + creation.unit_symbol() + "'s\n");
                }
                command="";
            }
            if(command.equals("exit") || command.equals("Exit") || command.equals("EXIT")) {
                printing = false;
            }
        }
        System.out.println("\nGoodbye!");
    }
}