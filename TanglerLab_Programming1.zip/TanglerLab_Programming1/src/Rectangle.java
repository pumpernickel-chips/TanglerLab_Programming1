public class Rectangle {
    private int x_width;
    private int y_height;
    private String character;
    public Rectangle(int width, int height, String symbol) {
        this.x_width=width;
        this.y_height=height;
        this.character=symbol;
    }
    public int calculate_area() {
        int area = (x_width * y_height);
        return area;
    }
    public int calculate_perimeter() {
        int perimeter = ((2*x_width) + (2*y_height));
        return perimeter;
    }
    public String get_details_text() {
        String details="\t Width: " + x_width + "\n\tHeight: " + y_height + "\n\tSymbol: " + character +"\n";
        return details;
    }
    public String toString() {
        String render="";
        for(int y=y_height; y>0; y=y-1) {
            for (int x=x_width; x>0; x=x-1) {
                render = (render + character);
            }
            render = (render + "\n");
        }
        return render;
    }
    public String unit_symbol(){
        String print_symbol=character;
        return print_symbol;
    }
}
